def fibonacci(n):
    if n == 0 or n == 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)


n = int(input("Enter number of terms: "))
if n < 0:
    print("Please enter a non-negative number.")
else:
    for i in range(n):
        print(fibonacci(i), end=" ")
    print()
