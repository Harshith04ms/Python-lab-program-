import random

print("DICE SIMULATOR")
while True:
    choice = input("Do you want to roll the dice? (yes/no): ").strip().lower()

    if choice == "yes":
        number = random.randint(1, 6)
        print("You rolled:", number)
    elif choice == "no":
        print("Thank you for playing!")
        break
    else:
        print("Invalid choice. Please enter yes or no.")
