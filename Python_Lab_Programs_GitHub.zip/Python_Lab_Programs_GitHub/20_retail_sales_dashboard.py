import csv
import matplotlib.pyplot as plt

print("RETAIL SALES DASHBOARD")

with open("sales.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["Product", "Sales"])
    n = int(input("Enter the number of products: "))

    for i in range(n):
        product = input("Enter product name: ")
        sales = float(input("Enter sales amount: "))
        writer.writerow([product, sales])

products = []
amounts = []

with open("sales.csv", "r", newline="", encoding="utf-8") as file:
    reader = csv.reader(file)
    next(reader)
    print("\nSALES REPORT")
    for row in reader:
        product = row[0]
        amount = float(row[1])
        products.append(product)
        amounts.append(amount)
        print(product, ":", amount)

total_sales = sum(amounts)
print("\nTotal Sales:", total_sales)

if amounts:
    print("Highest Sales:", max(amounts))
    print("Lowest Sales:", min(amounts))
    plt.bar(products, amounts)
    plt.title("Retail Sales Dashboard")
    plt.xlabel("Products")
    plt.ylabel("Sales Amount")
    plt.tight_layout()
    plt.show()
else:
    print("No sales data available to plot.")
