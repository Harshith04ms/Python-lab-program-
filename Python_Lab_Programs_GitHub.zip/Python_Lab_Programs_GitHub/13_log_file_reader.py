try:
    with open("log.txt", "r", encoding="utf-8") as file:
        error_count = 0
        print("--- LOG FILE CONTENTS ---")
        for line in file:
            print(line.strip())
            if "ERROR" in line:
                error_count += 1
        print("\nTotal ERROR messages:", error_count)
except FileNotFoundError:
    print("Log file does not exist!")
